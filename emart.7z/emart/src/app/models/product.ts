export class Product {
  category: string;
  subcategory: string;
  itemname: string;
  price: number;
  numOfStockItems: number;
  nwtype: string;
  memorystorage: string;
  screenresolution: string;
  weight: string;
  withlength: string;
  token?: string;
}