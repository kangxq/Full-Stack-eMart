export class Register {
  username: string;
  password1: string;
  password2: string;
  basicSelect: string;
  emalid: string;
  mobileNumber: string;
  companyname: string;
  gstin: string;
  briefaboutcompany: string;
  postaladdress: string;
  website: string;
  emalidseller: string;
  contactnumber: string;
  token?: string;
}