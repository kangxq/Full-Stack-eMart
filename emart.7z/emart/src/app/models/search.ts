export class Search {
  productName: string;
  token?: string;
}

export class SearchResults {
  productName: string;
  token?: string;
}
