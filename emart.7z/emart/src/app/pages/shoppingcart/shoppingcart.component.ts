import { Component, Input } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { ShoppingCartService } from '../../services/ShoppingCart.service';
import { Router } from '@angular/router';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

interface ProductItemResults {
  id: string;
  price: number;
  title: string;
  details: string;
  number: string;
  numberEdit : boolean;
}
const PAGE_COUNT : number = 5;
const PRODUCTS: ProductItemResults[] = [{
    id: '1',
    price: 3299,
    title: 'Thum bnail1',
    details: 'Samsung Galaxy s7',
    number: '10',
    numberEdit: false
  }, {
    id: '2',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    number: '130',
    numberEdit: false
  }, {
    id: '3',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    number: '104',
    numberEdit: false
  }, {
    id: '4',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    number: '150',
    numberEdit: false
  }, {
    id: '5',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    number: '107',
    numberEdit: false
  }, {
    id: '6',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    number: '1011',
    numberEdit: false
  }
];

interface DiscountsItem {
  id : number;
  title: string;
  number: number;
}
const DISCOUNTS: DiscountsItem[] = [{
    id: 1,
    title: 'Coupons over 199 minus 20',
    number: 1
  }, {
    id: 2,
    title: 'Coupons over 1999 minus 400',
    number: 2
  }, {
    id: 3,
    title: 'Coupons over 299 minus 40',
    number: 3
  }, {
    id: 4,
    title: 'Coupons over 3999 minus 600',
    number: 56
  }, {
    id: 5,
    title: 'Coupons over 50 minus 49',
    number: 77
  }
];

@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingCartComponent {

  products: ProductItemResults[];
  pageIndex : Number = 1;
  pageCount : Number = 5;
  totalTax : any;
  totalPrice : any;
  totalSumPrice : any;
  closeResult : string;
  totalPricesub : any;
  disflg : boolean;
  discountCode : any;
  constructor(private router: Router, private routeInfo: ActivatedRoute, 
          private shoppingCartService: ShoppingCartService,
          private modalService: NgbModal) {

    //shoppingCartService.searchResults();
    this.products = PRODUCTS;
    this.totalTax = 9999;
    this.totalSumPrice = 99999;
    this.totalPrice = this.totalSumPrice;
    this.totalPricesub = 0;
    this.disflg = false;
  }

  backToSearch(): void {
    this.router.navigate(['/search']);
  }

  editproduct(value : ProductItemResults) : void {
    value.numberEdit = true;
  }

  saveproduct(value : ProductItemResults) : void {
    //shoppingCartService.saveproduct(value)
    value.numberEdit = false;
  }

  deleteproduct(id): void {
    //shoppingCartService.deleteproduct(id)
    this.products = PRODUCTS;
  }

  checkout(): void {
    //shoppingCartService.checkout();
  }

  applyDiscount(content): void {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `${result}`;
    }, (reason) => {
      this.closeResult = `${reason}`;
    });
  }

  applyDiscountOk(modal): void{
    modal.close();
    console.log(this.discountCode);
    if (this.discountCode != null && this.discountCode != '') {
      //shoppingCartService.applyDiscount(this.discountCode);
      this.totalPricesub = 1000;
      this.totalPrice = this.totalSumPrice - this.totalPricesub;
      this.disflg = true;
    } else {
      this.totalPrice = this.totalSumPrice
      this.totalPricesub = 0;
      this.disflg = false;
    }
  }
}
