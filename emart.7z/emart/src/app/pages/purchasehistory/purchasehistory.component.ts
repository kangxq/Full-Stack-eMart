import { Component } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { PurchaseHistoryService } from '../../services/purchasehistory.service';
import { Router } from '@angular/router';

interface ProductItemResults {
  id: string;
  price: number;
  title: string;
  details: string;
  buydate: string;
}
const PAGE_COUNT : number = 5;
const PRODUCTS: ProductItemResults[] = [{
    id: '1',
    price: 3299,
    title: 'Thum bnail1',
    details: 'Samsung Galaxy s7',
    buydate: '5th Nov 2019'
  }, {
    id: '2',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    buydate: '2nd Nov 2019'
  }, {
    id: '3',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    buydate: '29th Oct 2019'
  }, {
    id: '4',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    buydate: '21st Otc 2019'
  }, {
    id: '5',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    buydate: '19th Otc 2019'
  }, {
    id: '6',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    buydate: '20th Otc 2019'
  }
];

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.component.html',
  styleUrls: ['./purchasehistory.component.css']
})
export class PurchaseHistoryComponent {

  products: ProductItemResults[];
  searchKey : String;
  moredateflg : boolean;
  pageIndex : Number = 1;
  pageCount : Number = 5;
  constructor(private router: Router, private routeInfo: ActivatedRoute, private purchaseHistoryService: PurchaseHistoryService) {
    
    this.moredateflg = false;

    //purchaseHistoryService.searchResults();
    if (PRODUCTS.length > PAGE_COUNT) {
      this.products = PRODUCTS.slice(0, this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
    }
  }

  backTosr() : void {
    this.router.navigate(['/search']);
  }

  viewDetails(value): void {
    this.router.navigate(['/specificationshistory'], { queryParams: {id: value, searchname: this.searchKey} });
  }

  dateShowMore(): void {
    this.pageIndex = this.pageIndex.valueOf() + 1;
    if (PRODUCTS.length > PAGE_COUNT*this.pageIndex.valueOf()) {
      this.products = PRODUCTS.slice(0, PAGE_COUNT*this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
      this.moredateflg = false;
    }
    console.log("searchname:" + PRODUCTS.length);
  }
}
