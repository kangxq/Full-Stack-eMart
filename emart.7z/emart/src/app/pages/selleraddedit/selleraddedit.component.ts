import { Component } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { SellerAddEditService } from '../../services/SellerAddEdit.service';
import { Router } from '@angular/router';
import { Product } from '../../models/product';

interface ItemList {
  value: string;
  name: string;
}
const ITEM: ItemList[] = [{
  value :'',
  name :''
},{
  value :'1',
  name :'computer'
},{
  value :'2',
  name :'apple'
}]

const NWTYPE: ItemList[] = [{
  value :'',
  name :''
},{
  value :'1',
  name :'2G'
},{
  value :'2',
  name :'3G'
},{
  value :'3',
  name :'4G'
},{
  value :'4',
  name :'5G'
}]

interface ProductItem {
  category: string;
  subcategory: string;
  itemname: string;
  price: number;
  numOfStockItems: number;
  nwtype: string;
  memorystorage: string;
  screenresolution: string;
  weight: string;
  withlength: string;
}
const PRODUCTITEM : ProductItem[] =[
  {
    category : '1',
    subcategory: '2',
    itemname : 'ABCDEFG',
    price : 999,
    numOfStockItems : 10000,
    nwtype : '3',
    memorystorage : '4',
    screenresolution : '150*256',
    weight : '1569g',
    withlength : '152mm*1563mm',
  }
]
@Component({
  selector: 'app-selleraddedit',
  templateUrl: './selleraddedit.component.html',
  styleUrls: ['./selleraddedit.component.css']
})

export class SellerAddEditComponent {

    id :string;
    listCategory :ItemList[]; 
    listSubcategory:ItemList[]; 
    nwType :ItemList[]; 
    memory:ItemList[]; 
    product : ProductItem[];
  constructor(private router: Router, private routeInfo: ActivatedRoute, 
                private sellerAddEditService: SellerAddEditService) {
    routeInfo.queryParams.subscribe(queryParams => {
      if(queryParams!=null){
        this.id = queryParams.id;
      }
    });
    this.listCategory = ITEM;
    this.listSubcategory = ITEM;
    this.nwType = NWTYPE;
    this.memory = NWTYPE;
    if (this.id != null) {
      this.product = PRODUCTITEM;
      // this.sellerAddEditService.getProduct(this.id).subscribe(
      //   data => {
      //     console.log(JSON.stringify(data));
      //     this.product = PRODUCTITEM;
      //   }
      // );
    }
  }


  onSubmit(value: any) {
    //service
    //this.sellerAddEditService.addProduct(value);
    this.router.navigate(['/sellerproduct']);
  }

}
