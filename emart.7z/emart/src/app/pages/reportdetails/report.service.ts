import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {Search} from '../models/search';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http: HttpClient) { 
    
  }

  public get currentUserToken(): string {
    return sessionStorage.getItem('token');
  }

  searchResults() {
    return this.http.post(`${environment.baseUrl}/report`,httpOptions);
  }
  searchResultsByDate(value) {
    return this.http.post(`${environment.baseUrl}/report/search`, JSON.stringify(value), httpOptions);
  }
  
}
