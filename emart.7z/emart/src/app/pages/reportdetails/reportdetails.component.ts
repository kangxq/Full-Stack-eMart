import { Component } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { ReportDetailService } from '../../services/ReportDetail.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

interface ProductItemResults {
  id: string;
  monetofsum: number;
  title: string;
  details: string;
  number: number;
}
const PRODUCTS: ProductItemResults[] = [{
  id: '1',
  monetofsum: 3299,
  title: 'Thum bnail1',
  details: 'Samsung Galaxy s7',
  number: 1099
}, {
  id: '2',
  monetofsum: 4999,
  title: 'Thum bnail',
  details: 'Oppo A5s',
  number: 1088
}, {
  id: '3',
  monetofsum: 4999,
  title: 'Thum bnail',
  details: 'Oppo A5s',
  number: 10
}, {
  id: '4',
  monetofsum: 4999,
  title: 'Thum bnail',
  details: 'Oppo A5s',
  number: 107
}, {
  id: '5',
  monetofsum: 4999,
  title: 'Thum bnail',
  details: 'Oppo A5s',
  number: 106
}, {
  id: '6',
  monetofsum: 4999,
  title: 'Thum bnail',
  details: 'Oppo A5s',
  number: 90
}
];
const PAGE_COUNT : number = 5;

@Component({
  selector: 'app-reportdetails',
  templateUrl: './reportdetails.component.html',
  styleUrls: ['./reportdetails.component.css']
})
export class ReportDetailsComponent {
  products: ProductItemResults[];
  moredateflg : boolean;
  id : string;
  startdate : Date;
  enddate : Date;
  pageIndex : Number = 1;
  pageCount : Number = 5;
  constructor(private router: Router, private routeInfo: ActivatedRoute, 
    private reportDetailService: ReportDetailService, private location: Location) {
    
    this.moredateflg = false;

    routeInfo.queryParams.subscribe(queryParams => {
      if(queryParams!=null){
        this.id = queryParams.id;
        this.startdate = queryParams.startdate;
        this.enddate = queryParams.enddate
      }
    });
    //reportDetailService.searchResults(id,startdate, enddate);
    if (PRODUCTS.length > PAGE_COUNT) {
      this.products = PRODUCTS.slice(0, this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
    }
  }

  backClicked() {
    this.location.back();
  }

  dateShowMore(): void {
    this.pageIndex = this.pageIndex.valueOf() + 1;
    if (PRODUCTS.length > PAGE_COUNT*this.pageIndex.valueOf()) {
      this.products = PRODUCTS.slice(0, PAGE_COUNT*this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
      this.moredateflg = false;
    }
  }
}
