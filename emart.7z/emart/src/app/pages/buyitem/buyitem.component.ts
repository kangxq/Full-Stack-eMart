import { Component } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { SearchService } from '../../services/search.service';
import { Router } from '@angular/router';


interface ProductItemResults {
  id: string;
  price: number;
  title: string;
  details: string;
  sellerUser: string;
}
const PAGE_COUNT : number = 5;
const PRODUCTS: ProductItemResults[] = [{
    id: '1',
    price: 3299,
    title: 'Thum bnail1',
    details: 'Samsung Galaxy s7',
    sellerUser: 'Seller1'
  }, {
    id: '2',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller2'
  }, {
    id: '3',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller3'
  }, {
    id: '4',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller4'
  }, {
    id: '5',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller5'
  }, {
    id: '6',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller6'
  }, {
    id: '7',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller7'
  }, {
    id: '8',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller8'
  }, {
    id: '9',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller9'
  }, {
    id: '10',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller10'
  }, {
    id: '11',
    price: 4999,
    title: 'Thum bnail',
    details: 'Oppo A5s',
    sellerUser: 'Seller11'
  }
];

@Component({
  selector: 'app-buyitem',
  templateUrl: './buyitem.component.html',
  styleUrls: ['./buyitem.component.css']
})

export class BuyItemComponent {

  products: ProductItemResults[];
  moredateflg : boolean;
  pageIndex : Number = 1;
  pageCount : Number = 5;
  constructor(private router: Router, private routeInfo: ActivatedRoute, private searchService: SearchService) {
    
    this.moredateflg = false;

    //searchService.searchResults();
    console.log("searchname:" + PRODUCTS.length);
    if (PRODUCTS.length > PAGE_COUNT) {
      this.products = PRODUCTS.slice(0, this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
    }
  }

  viewDetails(value): void {
    this.router.navigate(['/specifications'], { queryParams: {id: value} });
  }

  dateShowMore(): void {
    this.pageIndex = this.pageIndex.valueOf() + 1;
    if (PRODUCTS.length > PAGE_COUNT*this.pageIndex.valueOf()) {
      this.products = PRODUCTS.slice(0, PAGE_COUNT*this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
      this.moredateflg = false;
    }
  }
}
