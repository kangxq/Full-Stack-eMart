import { Component } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { SpecificationsHistoryService } from '../../services/SpecificationsHistory.service';
import { Router } from '@angular/router';

interface ProductItemResults {
  id: string;
  price: number;
  details: string;
  sellerUser: string;
  buytime: string;
  screenResolution: string;
  networkType: string;
  batteryCapacity: string;
  memoryStorage: string;
  img1: string,
  img2: string,
  img3: string,
  img4: string,
}

const PRODUCTS: ProductItemResults[] = [{
  id: '1',
  price: 3299,
  details: 'Samsung Galaxy s7',
  sellerUser: 'Seller1',
  buytime: '5th Nov 2019',
  screenResolution:'Cameras',
  networkType:'4G',
  batteryCapacity:'OS Version',
  memoryStorage:'2G',
  img1:'/assets/img/shopping1.jpg',
  img2:'/assets/img/shopping2.jpg',
  img3:'/assets/img/shopping3.jpg',
  img4:'/assets/img/shopping4.jpg'
}]

@Component({
  selector: 'app-specificationshistory',
  templateUrl: './specificationshistory.component.html',
  styleUrls: ['./specificationshistory.component.css']
})
export class SpecificationsHistoryComponent {
  id : string
  searchKey : string;
  imgPath : string;
  products: ProductItemResults[];
  
  constructor(private router: Router, private routeInfo: ActivatedRoute, 
          private specificationsHistoryService: SpecificationsHistoryService) {
    routeInfo.queryParams.subscribe(queryParams => {
      if(queryParams!=null){
        this.searchKey = queryParams.searchname;
        this.id = queryParams.id;
      }
    });
    //specificationsHistoryService.searchResults(this.id);
    this.products = PRODUCTS;
    this.imgPath = PRODUCTS[0].img1;
  }

  getPath(value) : void {
    if (value == 1) {this.imgPath = PRODUCTS[0].img1;}
    if (value == 2) {this.imgPath = PRODUCTS[0].img2;}
    if (value == 3) {this.imgPath = PRODUCTS[0].img3;}
    if (value == 4) {this.imgPath = PRODUCTS[0].img4;}
  }

  backToph() : void {
    this.router.navigate(['/purchasehistory']);
  }
}
