import { Component } from '@angular/core';
import { ActivatedRoute, Route} from '@angular/router';
import { WiewSiscountsService } from '../../services/viewdiscounts.service';
import { Router } from '@angular/router';


interface ProductItemResults {
  code:string;
  title: string;
  number: number;
}
const PAGE_COUNT : number = 5;
const PRODUCTS: ProductItemResults[] = [{
    code: '20200001',
    title: 'Coupons over 199 minus 20',
    number: 1
  }, {
    code: '20200002',
    title: 'Coupons over 1999 minus 400',
    number: 2
  }, {
    code: '20200003',
    title: 'Coupons over 299 minus 40',
    number: 3
  }, {
    code: '20200003',
    title: 'Coupons over 3999 minus 600',
    number: 56
  }, {
    code: '20200005',
    title: 'Coupons over 50 minus 49',
    number: 77
  }, {
    code: '20200006',
    title: 'Coupons over 9999 minus 2000',
    number: 100
  }, {
    code: '20200007',
    title: 'Coupons over 999 minus 300',
    number: 11
  }, {
    code: '20200008',
    title: 'Coupons over 19900 minus 5000',
    number: 12
  }, {
    code: '20200009',
    title: 'Coupons over 499 minus 200',
    number: 13
  }, {
    code: '20200010',
    title: 'Coupons over 599 minus 80',
    number: 14
  }, {
    code: '20200011',
    title: 'Coupons over 1888 minus 300',
    number: 15
  }
];

@Component({
  selector: 'app-viewdiscounts',
  templateUrl: './viewdiscounts.component.html',
  styleUrls: ['./viewdiscounts.component.css']
})

export class ViewDiscountsComponent {

  products: ProductItemResults[];
  moredateflg : boolean;
  pageIndex : Number = 1;
  pageCount : Number = 5;
  constructor(private router: Router, private routeInfo: ActivatedRoute, 
    private siewSiscountsService: WiewSiscountsService) {
    
    this.moredateflg = false;

    //siewSiscountsService.searchResults();
    console.log("searchname:" + PRODUCTS.length);
    if (PRODUCTS.length > PAGE_COUNT) {
      this.products = PRODUCTS.slice(0, this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
    }
  }

  viewDetails(value): void {
    console.log("value:" + value);
    this.router.navigate(['/specifications'], { queryParams: {id: value} });
  }

  dateShowMore(): void {
    this.pageIndex = this.pageIndex.valueOf() + 1;
    if (PRODUCTS.length > PAGE_COUNT*this.pageIndex.valueOf()) {
      this.products = PRODUCTS.slice(0, PAGE_COUNT*this.pageCount.valueOf());
      this.moredateflg = true;
    } else {
      this.products = PRODUCTS;
      this.moredateflg = false;
    }
    console.log("searchname:" + PRODUCTS.length);
  }
}
