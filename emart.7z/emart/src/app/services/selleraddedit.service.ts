import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {Product} from '../models/Product';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SellerAddEditService {

  product : Product;

  constructor(private http: HttpClient) { 
    
  }

  public get currentUserToken(): string {
    return sessionStorage.getItem('token');
  }

  addProduct(value) {
    return this.http.post(`${environment.baseUrl}/selleraddedit/add`, JSON.stringify(value), httpOptions);
  }

  editProduct(value) {
    return this.http.post(`${environment.baseUrl}/selleraddedit/edit`, JSON.stringify(value), httpOptions);
  }

  getProduct(value)  {
    return this.http.post(`${environment.baseUrl}/selleraddedit/search`, JSON.stringify(value), httpOptions);
  }

}
