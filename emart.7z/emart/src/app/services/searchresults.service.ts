import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {Search} from '../models/search';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SearchResultsService {

  constructor(private http: HttpClient) { 
    
  }

  public get currentUserToken(): string {
    return sessionStorage.getItem('token');
  }

  allSearchResults1(searchname) {
    return this.http.post(`${environment.baseUrl}/search/searchbyname`, JSON.stringify(searchname), httpOptions);
  }
  allSearchResults2(value) {
    return this.http.post(`${environment.baseUrl}/search/searchbykey`, JSON.stringify(value), httpOptions);
  }

}
