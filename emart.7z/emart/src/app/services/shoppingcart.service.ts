import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {Search} from '../models/search';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartService {

  constructor(private http: HttpClient) { 
    
  }

  public get currentUserToken(): string {
    return sessionStorage.getItem('token');
  }

  saveproduct(value) {
    return this.http.post(`${environment.baseUrl}/shoppingcart/save`, JSON.stringify(value), httpOptions);
  }

  deleteproduct(id) {
    return this.http.post(`${environment.baseUrl}/shoppingcart/delete`, JSON.stringify(id), httpOptions);
  }
  checkout(code) {
    return this.http.post(`${environment.baseUrl}/shoppingcart/checkout`, JSON.stringify(code), httpOptions);
  }
  applyDiscountOk(code) {
    return this.http.post(`${environment.baseUrl}/shoppingcart/applyDiscountOk`, JSON.stringify(code), httpOptions);
  }
}
