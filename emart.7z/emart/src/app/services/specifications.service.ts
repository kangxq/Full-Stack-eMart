import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';

interface value {
  id : string;
  number: number;
}

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SpecificationsService {
  value : value[];
  constructor(private http: HttpClient) { 
    
  }

  public get currentUserToken(): string {
    return sessionStorage.getItem('token');
  }

  searchbyid(id : string) {
    return this.http.post(`${environment.baseUrl}/specifications/searchbyid`, JSON.stringify(id), httpOptions);
  }
  checkout(id : string, number:number) {
    this.value[0].id = id;
    this.value[0].number = number;
    return this.http.post(`${environment.baseUrl}/specifications/checkout`, JSON.stringify(this.value), httpOptions);
  }
  addtocart(id : string, number:number) {
    this.value[0].id = id;
    this.value[0].number = number;
    return this.http.post(`${environment.baseUrl}/specifications/addtocart`, JSON.stringify(this.value), httpOptions);
  }
}
